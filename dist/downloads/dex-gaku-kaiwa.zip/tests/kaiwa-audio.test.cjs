/* Check shipped MP3 coverage independently from mocked playback tests. */
const fs=require('node:fs'),vm=require('node:vm'),assert=require('node:assert/strict');
const c={window:{}};vm.createContext(c);vm.runInContext(fs.readFileSync('dist/kaiwa-data.js','utf8'),c);
const expected=c.window.GAKU_KAIWA_DATA.flatMap(s=>s.lines.map((_,i)=>`${s.id}-${i+1}.mp3`)).sort();
const actual=fs.readdirSync('dist/assets/kaiwa').filter(x=>x.endsWith('.mp3')).sort();
assert.equal(expected.length,80);assert.deepEqual(actual,Array.from(expected));
for(const name of actual){assert.match(name,/^[a-z]+-[1-8]\.mp3$/);const bytes=fs.readFileSync('dist/assets/kaiwa/'+name);assert.ok(bytes.length>100);assert.ok(bytes.subarray(0,3).toString()==='ID3'||bytes[0]===255&&(bytes[1]&224)===224,name+' MP3 signature');}
console.log('PASS: all 80 shipped MP3s match the 10 scenarios and line numbers exactly, no extra/missing audio, valid non-empty MP3 signatures');
